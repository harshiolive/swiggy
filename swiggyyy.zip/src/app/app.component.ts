import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from "./header/header.component";
import { FoodComponent } from "./food/food.component";
import { DineoutComponent } from "./dineout/dineout.component";
import { FooterComponent } from "./footer/footer.component";
import { FoodPageComponent } from './food-page/food-page.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FoodComponent, DineoutComponent, FooterComponent,FoodPageComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'swiggy';
}
