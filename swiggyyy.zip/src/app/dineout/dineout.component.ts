import { Component } from '@angular/core';

@Component({
  selector: 'app-dineout',
  standalone: true,
  imports: [],
  templateUrl: './dineout.component.html',
  styleUrl: './dineout.component.css'
})
export class DineoutComponent {

}
