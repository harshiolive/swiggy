import { Component } from '@angular/core';

@Component({
  selector: 'app-food-page',
  standalone: true,
  imports: [],
  templateUrl: './food-page.component.html',
  styleUrl: './food-page.component.css'
})
export class FoodPageComponent {

}
